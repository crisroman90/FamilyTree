
package assignment.pkg2;

/**
 * Class which contains the main function
 */
public class Assignment2 {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TreeGUI treeGUI = new TreeGUI();
    } 
}
